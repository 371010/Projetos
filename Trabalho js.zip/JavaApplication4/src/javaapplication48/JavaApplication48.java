
package javaapplication48;


public class JavaApplication48 {

   
     
    public static void main(String[] args) {
        public class Funcionario {
     private String nome;
    private String Função;
    private int RegistroFuncionario;
    private double pagamento;
    private Funcionario anterior, proximo;

    
    public Funcionario(String nome, String Função, int RegistroFuncionario, double pagamento, Funcionario anterior, Funcionario proximo){
        this.nome = nome;
        this.Função = Função;
        this.RegistroFuncionario = RegistroFuncionario;
        this.pagamento = pagamento;
        this.anterior = anterior;
        this.proximo = proximo;  
    }

    public String getnome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFunção() {
        return Função;
    }

    public void setFunção(String Função) {
        this.Função = Função;
    }

    public int getRegistroFuncionario() {
        return RegistroFuncionario;
        
    }

    public void setRegistroFuncionario(int RegistroFuncionario) {
        this.RegistroFuncionario = RegistroFuncionario;
    }

    public double getpagamento() {
        return pagamento;
    }

    public void setSalario(double pagamento) {
        this.pagamento = pagamento;
    }

    public Funcionario getAnterior() {
        return anterior;
    }

    public void setAnterior(Funcionario anterior) {
        this.anterior = anterior;
    }

    public Funcionario getProximo() {
        return proximo;
    }

    public void setProximo(Funcionario proximo) {
        this.proximo = proximo;
    }
}
    }
    

