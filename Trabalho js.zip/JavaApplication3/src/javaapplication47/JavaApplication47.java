
package javaapplication47;


public class JavaApplication47 {

    
    public static void main(String[] args) {
        public class Metodos {
      
    private Elemento atual = null;
    private int TotalDeElementos = 0;
    
    public Elemento getAtual(){
        return atual;
    }
    
    
    public void inserirProduto(String NomeDoProduto , int Code,double valor,String Categoria, int quant){
        Elemento novo = new Elemento(NomeDoProduto, Code, valor,Categoria,quant,atual);
        this.atual = novo;
        TotalDeElementos++;
    }
    public void mostrar (Elemento x){
       System.out.println("");
        while (x!= null){
       System.out.println(x + "");
        x = x.getAnterior();
    }
       System.out.println("");    
   }
    public void pesquisar (Elemento x, Object objeto ){
    String st = (String) objeto;    
    while (x!= null){
     if(x.toString().contains(st)){
         System.out.println("Encontrei" + x);
         break;
     } 
      x = x.getAnterior(); 
   }
    if(x==null){
        System.out.println("Não encontrado");  
    }
 }
public boolean remover(Elemento y, int Code) {        
        if (atual != null) {
            Elemento x = y;
            while (y != null) {
                if (y.getCode()==Code) {
                    
                    if (y == atual) {
                        atual = atual.getAnterior();
                        y.setAnterior(null);
                        TotalDeElementos--;
                        return true;
                        
                    } else if (y.getAnterior() == null) {
                        x.setAnterior(null);
                        TotalDeElementos--;
                        return true;
                        
                    } else {
                        x.setAnterior(y.getAnterior());
                        y.setAnterior(null);
                        TotalDeElementos--;
                        return true;
                    }
                }
                x = y;
                y = y.getAnterior();
            }
        }
        return false;
    }
    public void Desconto(Elemento x,String Categoria, double Desconto){
        while(x!= null){
            if(x.getCategoria().equals(Categoria)){
                x.setvalor(x.getvalor()*Desconto);
        }
            x = x.getAnterior();
    }
        System.out.println("-----------------------------------");
        System.out.println("\ desconto total de : "+ (Desconto*100) + " % " + Categoria + "\n");
        System.out.println("-----------------------------------");
   }
    public void NotaFiscal(Elemento x){
        double soma = 0;
        System.out.println("============NOTA FISCAL============\n");
        System.out.println(" Todos Produtos Comprados: "+ TotalDeElementos + "\n" );
        System.out.println("===================================");
        System.out.println("PRODUTOS : ");
        
        while(x!= null){
            soma+= x.getvalor()*x.getquant();
            
            System.out.println("Produto: " + x.getNomeDoProduto());
            System.out.println("Código: " + x.getCode());
            System.out.println("Valor: " + x.getvalor() + "R$");
            System.out.println("Categoria: " + x.getCategoria());
            System.out.println("Quantidade de Produtos: " + x.getquant());
            System.out.println("Valor total dos itens: " + x.getvalor()* + x.getquant());
            System.out.println("");
            
            x = x.getAnterior();                   
    } 
            System.out.println("Valor da compra: " + soma);
            System.out.println("=====================");         
   }
    public void ListaDeCompras(Elemento x){
            System.out.println("========LISTA DE COMPRAS==========\n");
            System.out.println("Produtos a Comprar: "+ TotalDeElementos + "\n" );
            while(x!= null){
            System.out.println("Produto: " + x.getNomeDoProduto());
            System.out.println("Valor: " + x.getvalor() + "R$");
            System.out.println("Quantidade de Produtos: " + x.getquant());
            System.out.println("");
            
            x = x.getAnterior();
        }
            System.out.println("===================================");
    }
  }
    }
    

