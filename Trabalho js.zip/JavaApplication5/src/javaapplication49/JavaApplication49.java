/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication49;

/**
 *
 * @author lucca
 */
public class JavaApplication49 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        public class Main {

    public static void main(String[] args) {
                Metodos x = new Metodos();
        
        x.inserirFuncionarios("Lucas", "Programador.Senior",70957 , 2500);
        x.inserirFuncionarios("Joao", "CEO", 03754 ,5000);
        x.inserirFuncionarios("thais", "treinee", 745689, 1200);
        x.inserirFuncionarios("Guilherme", "Programador junior", 25448, 3900);
        
        x.relatorio(x.getAtual());
        
        x.pesquisar(x.getAtual(), 70957 );
        
        x.remover(x.getAtual(), 745689);
        
        x.relatorio(x.getAtual());
    }
    
}
    }
    

