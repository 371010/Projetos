
package javaapplication45;


public class JavaApplication45 {

   
    public static void main(String[] args) {
        
    public class Elemento {
    
    private Elemento Anterior;
    private String NomeProduto;
    private String Categoria ;
    private int Code;
    private int quantidade;
    private double valor;
    
    
    
    public Elemento(){
        
    }
    
    public Elemento(String NomeProduto,int Code,double valor, String Categoria,int quantidade,Elemento Anterior) {
        
        this.Anterior = Anterior; 
        this.NomeProduto = NomeProduto;
        this.Categoria = Categoria;
        this.Code = Code;
        this.quantidade = quantidade ;
        this.valor = valor ;
        
    }

    public Elemento getAnterior(){
        return Anterior;
    }
    public void setAnterior(Elemento Anterior){
        this.Anterior = Anterior;
    }
    public String getNomeProduto() {
        return NomeProduto;
    }

        public void setNomeDoProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto ;
    }

        public String getCategoria() {
        return Categoria;
    }
        public void setCategoria(String Categoria) {
        this.Categoria =Categoria ;
    }
        public int getCode() {
        return Code;
    }
        public void setCode(int Code) {
        this.Code = Code ;
    }
        public int getquantidade() {
        return  quantidade ;
    }
        public void setquant( int quantidade) {
        this.quantidade = quantidade ;
    }
        public double getvalor() {
        return valor ;
    }
        public void setvalor(double valor) {
        this.valor = valor ;
    }  

        /**
         *
         * @return
         */
        @Override
    public String toString() {
        return "{" + "NomeProduto= " + NomeProduto + ", Codigo= " + Code + " Preço= " + valor + " Categoria= " + Categoria +  " Quantidade= " + quantidade + '}';
    }

}
    }
    

