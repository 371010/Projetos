/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication50;

/**
 *
 * @author lucca
 */
public class JavaApplication50 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        [11:21 PM, 3/21/2021] Danilete Da Hornet: public class Metodos {
    private Funcionario inicio = null;
    private Funcionario atual, aux;
    private int quantidadeFuncionarios;

    public Metodos(){  
    }
    
    public void inserirFuncionarios(String Nome, String Função, int RegistroFuncionario, double salario){
        if(inicio == null){
        Funcionario x = new Funcionario(Nome, Função, RegistroFuncionario, salario, null, null);
        this.inicio = x;
        aux = inicio;
        }
        else {
        Funcionario x = new Funcionario(Nome, Função, RegistroFuncionario, salario, aux, null); 
        this.atual = x;
        aux.setProximo(atual);
        aux = atual; 
        }
        quantidadeFuncionarios++;
    }
    
    
    public void relatorio(Funcionario elemento){
        System.out.println("========== Relatório ===========" + "\n");   
        System.out.println("================================");
        System.out.println("Quantidade de Funcionarios: " + quantidadeFuncionarios);
        System.out.println("================================" + "\n");
        System.out.println("================================");
        
        while(elemento != null){
            System.out.println("Nome: " + elemento.getNome());
            System.out.println("Nivel: " + elemento.getFunção());
            System.out.println("Registro do Funcionario: " + elemento.getRegistroFuncionario());
            System.out.println("Pagamento : " + elemento.getPagamento());
            System.out.println("================================");
            
            elemento = elemento.getAnterior();
        }
    }    
    
    public boolean remover(Funcionario remov, int RegistroFuncionario) {
        if (atual != null) {
            Funcionario auxiliar = remov;
            while (remov != null) {
                if (remov.getRegistroFuncionario() == RegistroFuncionario) {
                    if (remov == atual) {
                        atual = atual.getAnterior();
                        remov.setAnterior(null);
                        quantidadeFuncionarios--;
                        return true;
                    } 
                    else if (remov.getAnterior() == null) {
                        auxiliar.setAnterior(null);
                        quantidadeFuncionarios--;
                        return true;
                    } 
                    else {
                        auxiliar.setAnterior(remov.getAnterior());
                        remov.setAnterior(null);
                        quantidadeFuncionarios--;
                        return true;
                    }
                }
                auxiliar = remov;
                remov = remov.getAnterior();
            }
        }
        return false;    
    }
    
        public void pesquisar(Funcionario elemento, int RegistroFuncionario) {
        while (elemento != null) {
            if (RegistroFuncionario == elemento.getRegistroFuncionario()) {  
                System.out.println("================================");
                System.out.println("====== Pesquisar Registro ======");
                System.out.println("================================" + "\n");
                System.out.println("Nome : " + elemento.getNome());
                System.out.println("nivel : " + elemento.getFunção());
                System.out.println("Registro do Funcionario: " + elemento.getRegistroFuncionario());
                System.out.println("Pagamento : " + elemento.getPagamento());
                
                break;
            }
            elemento = elemento.getAnterior();            
        }
        if (elemento == null) {
            System.out.println("Funcionario não reconhecido");
        }
    }
        
    public void exibir(Funcionario elemento){
        while(elemento != null){
            System.out.println("Nome: …
    }
    
}
