
package javaapplication46;


public class JavaApplication46 {

    
    public static void main(String[] args) {
        public class Main {

        /**
         *
         * @param args
         */
        public static void main(String[] args) {
        Metodos x = new Metodos();
        
        if(x.remover(x.getAtual(),4)){
        System.out.println("==================================");
        System.out.println("         Objeto Removido            ");
        System.out.println("==================================");
        }else{
        System.out.println("==================================");
        System.out.println("      Objeto não removido           ");
        System.out.println("==================================");
        }
        
        x.inserirProduto("Presunto",07,4.30,"Frios",1);
        x.inserirProduto("Cerveja",29,28.00,"Bebidas",3);
        x.inserirProduto("Manga",14,10,"Frutas",5);
        x.inserirProduto("Melancia",14,5,"Frutas",5);
        
        x.ListaDeCompras(x.getAtual());
        
        x.Desconto(x.getAtual(),"Frutas", 0.50);
        
        x.NotaFiscal(x.getAtual());
    }
    }
    }
    

